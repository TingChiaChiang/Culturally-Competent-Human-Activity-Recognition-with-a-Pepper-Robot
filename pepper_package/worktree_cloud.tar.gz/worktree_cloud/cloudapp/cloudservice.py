
#!/usr/bin/env python
import io
import os
import json
import qi
import sys

# Imports the Google Cloud client library
from google.cloud import vision
from google.cloud.vision import types
# from google.cloud import storage
os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/home/nao/Karen_files/google_cloud/Google_API_Key/Activities-012dafa2c159.json"

# os.system("export GOOGLE_APPLICATION_CREDENTIALS = %s" %("/home/karen/Vision_API/Google/Google_API_Key/Activities-012dafa2c159.json"))
# export GOOGLE_APPLICATION_CREDENTIALS =/home/karen/Vision_API/Google/Google_API_Key/Activities-012dafa2c159.json"

# Imports the Microsoft custom vision library
from azure.cognitiveservices.vision.customvision.prediction import prediction_endpoint
from azure.cognitiveservices.vision.customvision.prediction.prediction_endpoint import models





class cloudservice:
    def __init__(self, *args, **kwargs):
     #define a signal 'onBang'
        self.onBang = qi.Signal()

     #define a bang method that will trigger the onBang signal
    def bang(self):
       #trigger the signal with 42 as value
        self.onBang(42)
    def echo(self, message):
        return message

    def cloud_process(self,image_path, file_name_created):
        # Google: Instantiates a google client
        client = vision.ImageAnnotatorClient()

        # Microsoft: a trained endpoint that can be used to make a prediction
        prediction_key = "82399d964ace4ef8a3b8a8b5a2540540"
        predictor = prediction_endpoint.PredictionEndpoint(prediction_key)

        # iteration = trainer.train_project(3c2e78ba-4367-4941-8cf8-b668deb28726)

        # project_id = "3c2e78ba-4367-4941-8cf8-b668deb28726"
        # Activity_Recognition_New
        project_id = "d620a7d4-2aec-42a1-8ea3-810077cdcbc2"
        # Activity_Recognition_Lab
        # project_id = "7aa1eeee-b74d-4f55-8012-c8f0bc10cb11"

        qi.path.setWritablePath("/home/nao/Karen_files")

        dataPath = qi.path.userWritableDataPath("cloudapp", file_name_created)
        # datapath => /home/nao/my_path/data/myapp/mydatafile
        confPath = qi.path.userWritableConfPath("cloudapp", file_name_created)
        # confPath => /home/nao/my_path/config/myapp/myconffile

        file = open(dataPath,'w')

        """create a list of file paths of images"""
        path = image_path
        # path ="/home/karen/Data_Caresses/Images/English/SEN_Activities/Reading/Test_data"
        dirs = os.listdir(path)
        image_list = []
        activity_highest =[]
        # print(dirs)

        for f in dirs:
            if f.endswith('jpg'):
                    image_list.append(os.path.join(path,f))

        # j_list.sort(key = lambda x: int(x.split('.')[-2].split('_')[-1]))
        image_list = sorted(image_list,key = lambda x: int(x.split('.')[-2].split('_')[-1]))
        # print(j_list)
        """write the returned labels  """
        # python_name = "google_microsoft_result_b_read.py"
        # python_name =  file_name_created

        file = open(dataPath,"w")
        for f in image_list:
            with open(dataPath,"a")as file:
                # file.write("-----------")
                file.write(f)
                # file.write("-----------")
                file.write("\n")
            with io.open(f, 'rb') as image_file:


                # google_labels
                content = image_file.read()
                image = types.Image(content=content)
                response = client.label_detection(image=image)
                labels = response.label_annotations
                for i in labels:
                    with open(dataPath,"a")as file:
                         file.write("#")
                         file.write(i.description.encode("utf-8"))
                         file.write("\n")

            # microsoft
            with io.open(f, 'rb') as image_file:
                results = predictor.predict_image(project_id, image_file)
                count = 0
                with open(dataPath, "a") as file:
                    for prediction in results.predictions:
                        if count == 0:

                            str = prediction.tag_name.encode("utf-8")
                            # print("highest score is "+str)

                            # activity_highest.append(str)
                            file.write("!")
                            file.write(str)
                            file.write("\n")
                        # print ("\t" + prediction.tag_name + ": {0:.2f}%".format(prediction.probability * 100))
                        file.write("---" + prediction.tag_name + ": {0:.2f}%".format(prediction.probability * 100))
                        count = count + 1
                    file.write("\n")

        file.close()

def main():
    app = qi.Application(sys.argv)
    # sys.argv
    app.start()
    session = app.session
    APIService =cloudservice()
    session.registerService("cloudservice", APIService)
    app.run()

if __name__ == "__main__":
    main()
